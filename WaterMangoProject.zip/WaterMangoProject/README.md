# WaterMango

Stack: .NET5, Angular 11, MSSql

Used Visual Studio 2019, Visual studio Code, MS Sql Server 2019 Express

STEPS-

Extract the WaterMangoProject.zip folder

To run frontend app-
cd WaterMangoUI
npm i
ng serve --o

To run backend app-

setup initial db and run migrations- Go to Nuget Package Manager Console ->
Update-Database
Build solution and Run the app

visit http://localhost:4200/ and enjoy watering the mango plants :)
