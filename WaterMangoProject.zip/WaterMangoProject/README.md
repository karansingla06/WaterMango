# WaterMango
.NET5, Angular 11 app

Used Visual Studio 2019, Visual studio Code, MS Sql Server 2019 Express <br>

To run frontend app- 
```cd WaterMangoUI``` <br>
```npm i``` <br>
```ngserve --o```


To run backend app-
1. Build solution

2. setup initial db and run migrations-
Go to Nuget Package Manager Console ->
```Update-Database```

3. Run the app

