﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WaterMango.Migrations
{
    public partial class InitialData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                INSERT INTO Plants ( Name, BeingWatered, Active) 
                VALUES ('p1', 0, 1), ('p2', 0, 1), ('p3', 0, 1), ('p4', 0, 0), ('p5', 0, 1);
");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
