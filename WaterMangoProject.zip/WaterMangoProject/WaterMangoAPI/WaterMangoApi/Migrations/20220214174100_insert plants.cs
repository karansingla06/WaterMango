﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PaymentApi.Migrations
{
    public partial class insertplants : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO Plants ( Name, BeingWatered, Active) VALUES ('p1', 0, 1), ('p2', 0, 1), ('p3', 0, 1), ('p4', 0, 1), ('p5', 0, 1);");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
