﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using PaymentAPI.Models;

namespace PaymentApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlantController : ControllerBase
    {
        private readonly PlantDbContext _context;
        private static Dictionary<int, CancellationTokenSource> plantsBeingWateredTokens = new();

        public PlantController(PlantDbContext context)
        {
            _context = context;
        }


        // GET api/Plant
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Plant>>> GetPlantsAsync()
        {
            var plants = await _context.Plants.ToListAsync();
            return plants;
        }


        // GET api/Plant
        [HttpGet("AboutToDie")]
        public async Task<ActionResult<List<string>>> GetPlantsStatusAsync()
        {
            List<string> plantsThatNeedWater = new List<string>();
            var allPlants = await _context.Plants.ToListAsync();
            var now = DateTime.UtcNow;

            plantsThatNeedWater = allPlants.Where(plant => plant.LastWatered.HasValue && (now - (DateTime)plant.LastWatered).TotalSeconds > 6 * 60 * 60)
                                            .Select(p => p.Name).ToList();

            return plantsThatNeedWater;
    }


        // GET api/Plant/1
        [HttpGet("{id}")]
        public async Task<ActionResult<Plant>> GetPlantAsync(int id)
        {
            var plant = await _context.Plants.FindAsync(id);

            if (plant == null)
            {
                return NotFound();
            }

            return plant;
        }


        // POST api/Plant/Water
        [HttpPost("Water")]
        public async Task<ActionResult<Plant>> WaterPlant([FromBody] int id)
        {
            var plant = await _context.Plants.FindAsync(id);
            if (plant == null)
            {
                throw new Exception($"Plant with id: {id} not found");
            }

            if (plant.BeingWatered)
            {
                throw new Exception($"Plant {plant.Name} is being watered");
            }
            else if (plant.LastWatered.HasValue && (DateTime.UtcNow - (DateTime)plant.LastWatered).TotalSeconds < 30)
            {
                throw new Exception($"Plant {plant.Name} has to rest 30 seconds before it can be watered again from the last session.");
            }
            else
            {
                var tokenSource = new CancellationTokenSource();
                plantsBeingWateredTokens.Add(id, tokenSource);
                var cancellationToken = tokenSource.Token;

                plant.BeingWatered = true;
                await _context.SaveChangesAsync();

                Task.Delay(10000).Wait();
                plant.LastWatered = DateTime.UtcNow;
                plant.BeingWatered = false;

                if (cancellationToken.IsCancellationRequested)
                {
                    plantsBeingWateredTokens.Remove(id);
                    return NoContent();
                }
                else
                {
                    await _context.SaveChangesAsync();
                    plantsBeingWateredTokens.Remove(id);
                    return plant;
                }
            }

        }


        // POST api/Plant/StopWatering
        [HttpPost("StopWatering")]
        public async Task<ActionResult<Plant>> StopWateringPlant([FromBody] int id)
        {
            var plant = await _context.Plants.FindAsync(id);
            if (plant == null)
            {
                throw new Exception("Plant not found");
            }

            if (plantsBeingWateredTokens.ContainsKey(id))
            {
                plantsBeingWateredTokens[id].Cancel();
                plant.BeingWatered = false;
                await _context.SaveChangesAsync();
            }

            return plant;
        }



        // PUT: api/Plant/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePlant(int id, Plant plant)
        {
            if (id != plant.Id)
            {
                return BadRequest();
            }

            _context.Entry(plant).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlantExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        
        private bool PlantExists(int id)
        {
            return _context.Plants.Any(e => e.Id == id);
        }

    }
}
