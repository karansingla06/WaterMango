import { Component, OnInit } from '@angular/core';
import { PlantService } from '../shared/plant.service';
import { ToastrService } from 'ngx-toastr';
import { interval } from 'rxjs';

@Component({
  selector: 'app-plant-details',
  templateUrl: './plant-details.component.html',
  styles: [
  ]
})

export class PlantDetailsComponent implements OnInit {

    constructor(public service: PlantService,
        private toastr: ToastrService) { }

    ngOnInit(): void {
        this.service.refreshList();

        // called every 60 seconds 
        interval(60000)
            .subscribe(() => {
                this.service.getPlantsAboutToDie().subscribe(res => {
                    if(res?.length){
                        this.toastr.warning('Plants ' + res.toString() + ' not watered since 6 hours.');
                    }
                },
                err => { 
                    console.log(err);
                    this.toastr.error('An error occurred while checking plants which are about to die.'); 
                }
                );
            });
    }


    startWatering(id: number): void {
        if (confirm('Are you sure you want to start watering this plant: ' + id)) {
            this.toastr.show("Started watering plant with id:" + id);
            const index = this.service.plantList.findIndex(x => x.id === id);
            this.service.plantList[index].beingWatered = true;

            this.service.waterPlant(id)
                .subscribe(
                res => {
                    this.service.refreshList();
                    this.toastr.show("Watered plant " + res.name + " successfully");
                },
                err => { 
                    this.service.plantList[index].beingWatered = false;
                    this.toastr.error(err.error);
                }
            );
        }
    }

    stopWatering(id: number): void {
        if (confirm('Are you sure you want to stop watering this plant: ' + id)) {
            this.service.stopWateringPlant(id)
                .subscribe(
                res => {
                    this.service.refreshList();
                    this.toastr.show("Stopped watering plant " + res.name + " successfully");
                },
                err => {
                    this.toastr.error(err.error);
                 }
                );
            }
        }


    ngOnDestroy(){
    }

}


