import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Plant } from './plant.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlantService {

  constructor(private http: HttpClient) { }

  readonly baseURL = 'http://localhost:61236/api/Plant';

  formData2: Plant = new Plant();
  list2: Plant[];
  plantWaterStatusMap: any;

  // sets beingWatered to true while the plant is being watered for 10 sec. Resets the beingWatered to false and updates the LastWatered when finished
  waterPlant(id: number): Observable<any> {
    return this.http.post(this.baseURL + '/Water', id);
  }

  // sets beingWatered to false if plant is being watered
  stopWateringPlant(id: number): Observable<any> {
    return this.http.post(this.baseURL + '/StopWatering', id);
  }


  // get plant names which have not been watered since 6 hours
  getPlantsAboutToDie(): Observable<any> {
    return this.http.get(this.baseURL + '/AboutToDie');
  }


  refreshList() {
    this.http.get(this.baseURL)
      .toPromise()
      .then(res => {
        this.list2 = res as Plant[];
      });
  }

}
