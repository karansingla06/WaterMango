export class Plant {
    id: number = 0;
    name: string = '';
    beingWatered: boolean = false;
    active: boolean = true;
    lastUpdated: Date;
}
